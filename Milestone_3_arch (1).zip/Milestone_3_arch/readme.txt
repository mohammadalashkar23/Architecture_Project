Names: 
Hadj Ahmed Chikh Dahmane 
Mohammad Alashkar 
IDs: 
900214344
900214276
Release notes: 
- We implemented a pipelined risc-v datapath supporting all forty user-level instructions as well as the ones from the M-Extension. 
- We merged both the lab project and the previous milestone for this milestone.
- We fetch an instruction every two clock cycles which makes us get rid of load use hazards and get rid of the need to forward from the EX Stage.
- We used a sigle ported memory for both instructions and data such that we use 2KB for instructions and 2KB for data. The assumption here was that we add an offset of 2*1024-1 to the address to access the data. 
- We used the tests from the previous milestone as well as a new fibonnacci test. 
- We worked on two bonus features which are the instructions' generator and adding support for the M-Extension's instructions. 
- Adding the M-Extension compelled us to propagate funct7 to be passed to the control unit as well as adding one more bit to ALUSel.
- The random generator generates both assembly instructions and machine code.  
