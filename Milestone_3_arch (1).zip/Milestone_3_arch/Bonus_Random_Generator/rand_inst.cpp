// rand.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <random>
#include <bitset>
using namespace std;
int generateRandom(int n) {
	std::random_device rd;  // obtain a random number from hardware
	std::mt19937 gen(rd()); // seed the generator
	std::uniform_int_distribution<> distrib(0, n); // define the range

	return distrib(gen); // generate the random number
}
unsigned int Rr_type()
{
	unsigned int op = 0b0110011;
	unsigned int inst = op;
	unsigned int fun3 = generateRandom(7);
	unsigned int fun7 = generateRandom(1);
	if (fun7)
	{
		fun7 = 32;
	}
	unsigned int rd = generateRandom(31);
	unsigned int rs12 = generateRandom(1023);
	inst = (rd << 7) | inst;
	inst = (fun3 << 12) | inst;
	inst = (rs12 << 15) | inst;
	inst = (fun7 << 25) | inst;


	return inst;
}
unsigned int UJr_type()
{
	unsigned int op = 0b1101111;


	unsigned int inst = op;


	unsigned int rd = generateRandom(31);
	unsigned int rs12 = generateRandom(1048575);
	inst = (rd << 7) | inst;
	inst = (rs12 << 12) | inst;



	return inst;
}
unsigned int Ur_type()
{
	unsigned int op = generateRandom(1);
	if (op)
	{
		op = 0b0010111;
	}
	else
	{
		op = 0b0110111;
	}

	unsigned int inst = op;


	unsigned int rd = generateRandom(31);
	unsigned int rs12 = generateRandom(1048575);
	inst = (rd << 7) | inst;
	inst = (rs12 << 12) | inst;



	return inst;
}
unsigned int sr_type()
{
	unsigned int op = 0b0100011;
	unsigned int inst = op;
	unsigned int fun3 = generateRandom(2);
	unsigned int rt = generateRandom(4095);
	unsigned int rd = generateRandom(31);

	inst = (rd << 7) | inst;
	inst = (fun3 << 12) | inst;
	inst = (rt << 15) | inst;



	return inst;
}
unsigned int Ir_type()
{

	unsigned int op = generateRandom(4);
	switch (op)
	{
	case 0: op = 3;
		break;
	case 1: op = 15;
		break;
	case 2: op = 19;
		break;
	case 3: op = 103;
		break;
	case 4:  op = 115;
		break;


	default:
		op = 0;
		break;
	}
	unsigned int fun3;
	switch (op)
	{
	case 3:  fun3 = generateRandom(5);
		if (fun3 == 3)
		{
			fun3 = fun3 + 1;
		}

		break;
	case 15: fun3 = 0;
		break;
	case 19: fun3 = generateRandom(7);

		break;
	case 103: fun3 = 0;
		break;
	case 115:  fun3 = 0;
		break;


	default:
		op = 0;
		break;
	}


	//  unsigned int fun3 = generateRandom(7);

	unsigned int inst = op;
	unsigned int rt;
	rt = generateRandom(4095);
	if (op == 0b1110011)
	{
		rt = generateRandom(1);
	}
	else if (op == 0b0010011)
	{
		if (fun3 == 5)
		{
			rt = generateRandom(1);
			if (rt)
			{
				rt = 64;
			}
		}

	}
	

	unsigned int rd = generateRandom(31);

	inst = (rd << 7) | inst;
	inst = (fun3 << 12) | inst;
	inst = (rt << 15) | inst;


	return inst;

}
unsigned int sbr_type()
{

	unsigned int op = 0b1100011;

	unsigned int inst = op;
	unsigned int fun3 = generateRandom(7);
	if (fun3 < 4 && fun3>1)
	{
		fun3 = fun3 + 2;
	}
	unsigned int rd = generateRandom(31);
	unsigned int rt = generateRandom(4095);
	inst = (rd << 7) | inst;
	inst = (fun3 << 12) | inst;
	inst = (rt << 15) | inst;


	return inst;

}
unsigned int radominstruction()
{
	int type = generateRandom(5);
	switch (type)
	{
	case 0: return Rr_type();
		break;
	case 1:  return Ir_type();
		break;
	case 2:  return sr_type();
		break;
	case 3:  return sbr_type();
		break;
	case 4:  return Ur_type();
		break;
	case 5:  return UJr_type();
		break;

	default:
		cout << "not defined";
		break;
	}
	return Rr_type();
}
//I type
void I_type(unsigned int instWord)
{
	unsigned int rd, rs1, rs2, funct3, funct7, opcode;
	unsigned int I_imm, S_imm, B_imm, U_imm, J_imm;
	unsigned int address;



	opcode = instWord & 0x0000007F;
	rd = (instWord >> 7) & 0x0000001F;
	funct3 = (instWord >> 12) & 0x00000007;
	rs1 = (instWord >> 15) & 0x0000001F;
	rs2 = (instWord >> 20) & 0x0000001F;

	//  inst[31]  inst[30:25] inst[24:21] inst[20]
	I_imm = ((instWord >> 20) & 0x7FF) | (((instWord >> 31) ? 0xFFFFF800 : 0x0));

	unsigned shamt;
	shamt = I_imm & 0x01F;
	funct7 = (I_imm >> 5) & 0x07F;

	if (opcode == 0x13) {	// I instructions
		switch (funct3) {
		case 0:	cout << "\tADDI\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << (int)I_imm << "\n";

			break;
		case 1:	cout << "\tSLLI\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << shamt << "\n";

			break;
		case 2:	cout << "\tSLTI\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << (int)I_imm << "\n";

			break;
		case 3:	cout << "\tSLTIU\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << (int)I_imm << "\n";

			break;
		case 4:	cout << "\tXORI\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << (int)I_imm << "\n";

			break;
		case 5:
			switch (funct7) {
			case 0:	cout << "\tSRLI\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << shamt << "\n";

				break;
			case 32:	cout << "\tSRAI\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << shamt << "\n";

				break;
			default:
				cout << "\tUnkown I Instruction \n";
			}
			break;
		case 6:	cout << "\tORI\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << (int)I_imm << "\n";

			break;
		case 7:	cout << "\tANDI\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << (int)I_imm << "\n";

			break;
		default:
			cout << "\tUnkown I Instruction \n";
		}
	}
	else if (opcode == 0x3) {
		switch (funct3) {
		case 0:	cout << "\tLB\tx" << rd << ", " << (int)I_imm << " (x" << rs1 << ')' << "\n";

			break;
		case 1:	cout << "\tLH\tx" << rd << ", " << (int)I_imm << " (x" << rs1 << ')' << "\n";

			break;
		case 2:	cout << "\tLW\tx" << rd << ", " << (int)I_imm << " (x" << rs1 << ')' << "\n";

			break;
		case 4:	cout << "\tLBU\tx" << rd << ", " << (int)I_imm << " (x" << rs1 << ')' << "\n";


			break;
		case 5:	cout << "\tLHU\tx" << rd << ", " << (int)I_imm << " (x" << rs1 << ')' << "\n";

			break;
		default:
			cout << "\tUnkown I_load Instruction \n";
		}
	}
	else {
		cout << "\tJALR\tx" << rd << ", x" << rs1 << ", " << hex << "0x" << (int)I_imm << "\n";

	}
}
//R type
void R_Type(unsigned int instWord)
{
	unsigned int rd, rs1, rs2, funct3, funct7, opcode;
	unsigned int I_imm, S_imm, B_imm, U_imm, J_imm;
	unsigned int address;

	//unsigned int instPC = pc - 4;

	rd = (instWord >> 7) & 0x0000001F;
	funct3 = (instWord >> 12) & 0x00000007;
	rs1 = (instWord >> 15) & 0x0000001F;
	rs2 = (instWord >> 20) & 0x0000001F;
	funct7 = (instWord >> 25) & 0x0000007F;

	switch (funct3) {
	case 0:
		if (funct7 == 32) {
			cout << "\tSUB\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

		}
		else if (funct7 == 0) {
			cout << "\tADD\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

		}
		else {
			cout << "\tUnkown B Instruction \n";
		}
		break;

	case 1:
	{
		cout << "\tSLL\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

	}
	break;

	case 2:
	{
		cout << "\tSLT\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

	}
	break;

	case 3:
	{
		cout << "\tSLTU\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

	}
	break;

	case 4:
	{
		cout << "\tXOR\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

	}
	break;

	case 5:
		if (funct7 == 32) {
			cout << "\tSRA\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

		}
		else if (funct7 == 0) {
			cout << "\tSRL\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

		}
		else {
			cout << "\tUnkown B Instruction \n";
		}
		break;

	case 6:
	{
		cout << "\tOR\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

	}
	break;

	case 7:
	{
		cout << "\tAND\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";

	}
	break;

	default:
		cout << "\tUnkown B Instruction \n";

	}

}

//s type
void S_Type(unsigned int instWord) {
	unsigned int rd, rs1, rs2, funct3, funct7, opcode;
	int I_imm, S_imm, B_imm, U_imm, J_imm;
	unsigned int address;

	unsigned int instPC;

	opcode = instWord & 0x0000007F;
	rd = (instWord >> 7) & 0x0000001F;
	funct3 = (instWord >> 12) & 0x00000007;
	rs1 = (instWord >> 15) & 0x0000001F;
	rs2 = (instWord >> 20) & 0x0000001F;

	unsigned int temp = ((instWord >> 25) & 0x3F);
	S_imm = ((instWord >> 7) & 0x1F) | (temp << 5) | (((instWord >> 31) & 0x1) ? 0xFFFFF800 : 0x0);
	//  reg[rs1-1] = 10004; //for testing
	//  reg[rs2-1] = 0b01010101010101010101010101010101;  //for testing
	switch (funct3) {
	case 0: {

		cout << "\tSB\tx" << rs2 << ", " << S_imm << "(x" << rs1 << ")\n";



	}
		  break;

	case 1: {

		cout << "\tSH\tx" << rs2 << ", " << S_imm << "(x" << rs1 << ")\n";

		break;
	}
	case 2: {

		cout << "\tSW\tx" << rs2 << ", " << "0x" << S_imm << "(x" << rs1 << ")\n";


		break;
	}
	}
}

//u type 
void U_Type(unsigned int instWord) {
	unsigned int rd, rs1, rs2, funct3, funct7, opcode;
	unsigned int I_imm, S_imm, B_imm, U_imm, J_imm;
	unsigned int address;

	opcode = instWord & 0x0000007F;
	rd = (instWord >> 7) & 0x0000001F;
	funct3 = (instWord >> 12) & 0x00000007;
	rs1 = (instWord >> 15) & 0x0000001F;
	rs2 = (instWord >> 20) & 0x0000001F;


	U_imm = ((instWord >> 12) & 0x7FFFF) | (((instWord >> 31) ? 0xFFFFF800 : 0x0));
	if (rd != 0) {
		switch (opcode) {
		case 55: {
			cout << "\tLUI\tx" << rd << ", 0x" << std::hex << signed(U_imm) << "\n";

			break;
		}
		case 23: {
			cout << "\tAUIPC\tx" << rd << ", 0x" << std::hex << signed(U_imm) << "\n";

			break;
		}
		}
	}
	else {
		if (opcode == 55)
			cout << "\tLUI\tx" << 0 << ", 0x" << std::hex << signed(U_imm) << "\n";
		else
			cout << "\tAUIPC\tx" << 0 << ", 0x" << std::hex << signed(U_imm) << "\n";
	}
}

//B type
void B_Type(unsigned int instWord)
{
	unsigned int rs1, rs2, funct3, opcode;
	unsigned int B_imm2, B_imm1, B_imm = 0;
	unsigned int target_address;

	opcode = instWord & 0x0000007F;
	B_imm1 = (instWord >> 7) & 0x0000001F;//imm[4:1|11]
	funct3 = (instWord >> 12) & 0x00000007;
	rs1 = (instWord >> 15) & 0x0000001F;
	rs2 = (instWord >> 20) & 0x0000001F;

	B_imm2 = ((instWord >> 25) & 0x3F) | (((instWord >> 31) ? 0xFFFFFFC0 : 0x0)); //imm[12|10:5]
	B_imm = ((B_imm2 >> 6) << 1) & 0xFFFFFFFF;
	B_imm = B_imm | (B_imm1 & 0x00000001); //imm[12:11]
	B_imm = (B_imm << 6) | (B_imm2 & 0x0000003F); //imm[12:5]

	B_imm = (B_imm << 4) | ((B_imm1 >> 1) & 0x0000000F); //imm[12:1]
	B_imm = B_imm << 1; //imm[12:0]

	switch (funct3) {
	case 0: { cout << "\tBEQ\tx" << rs1 << ", x" << rs2 << ", " << hex << "0x" << (int)B_imm << "\n";

	}
		  break;
	case 1: {cout << "\tBNE\tx" << rs1 << ", x" << rs2 << ", " << hex << "0x" << (int)B_imm << "\n";

	}
		  break;
	case 4: {cout << "\tBLT\tx" << rs1 << ", x" << rs2 << ", " << hex << "0x" << (int)B_imm << "\n";

	}
		  break;
	case 5: {cout << "\tBGE\tx" << rs1 << ", x" << rs2 << ", " << hex << "0x" << (int)B_imm << "\n";

	}
		  break;
	case 6: {cout << "\tBLTU\tx" << rs1 << ", x" << rs2 << ", " << hex << "0x" << (int)B_imm << "\n";

	}
		  break;
	case 7: {cout << "\tBGEU\tx" << rs1 << ", x" << rs2 << ", " << hex << "0x" << (int)B_imm << "\n";

	}
		  break;
	default:
		cout << "\tUnkown B Instruction \n";
	}

}
//J type
void J_Type(unsigned int instWord) {
	unsigned int rd, opcode;
	unsigned int J_imm1, J_imm2, J_imm = 0;

	opcode = instWord & 0x0000007F;
	rd = (instWord >> 7) & 0x0000001F;


	J_imm1 = ((instWord >> 12) & 0x0007FFFF) | ((instWord >> 31) ? 0xFFF80000 : 0x0);//imm[20|10:1|11|19:12]
	J_imm = J_imm1 & 0xFFF80000; //imm[20]
	J_imm2 = (J_imm1 & 0x000000FF) << 1; //imm[19:12]
	J_imm1 = J_imm1 >> 8; //imm[20|10:1|11]
	J_imm2 = J_imm2 | (J_imm1 & 0x00000001);//imm[19:11]
	J_imm1 = J_imm1 >> 1; //imm[20|10:1]
	J_imm2 = J_imm2 << 10;
	J_imm2 = J_imm2 | (J_imm1 & 0x000003FF); //imm[19:1]

	J_imm = J_imm | J_imm2;
	J_imm = J_imm << 1;

	cout << "\tJAL\tx" << rd << ", " << hex << "0x" << J_imm << "\n";
}
void Ecall()
{
	cout << "\t" << "Ecall" << endl;

}
void instDecExec(unsigned int instWord)
{
	unsigned int rd, rs1, rs2, funct3, funct7 = 0, opcode;
	unsigned int I_imm, S_imm, B_imm, U_imm, J_imm;
	unsigned int address;



	opcode = instWord & 0x0000007F;
	rd = (instWord >> 7) & 0x0000001F;
	funct3 = (instWord >> 12) & 0x00000007;
	rs1 = (instWord >> 15) & 0x0000001F;
	rs2 = (instWord >> 20) & 0x0000001F;

	//  inst[31]  inst[30:25] inst[24:21] inst[20]
	I_imm = ((instWord >> 20) & 0x7FF) | (((instWord >> 31) ? 0xFFFFF800 : 0x0));



	if (opcode == 0x33) {		// R Instructions
		R_Type(instWord);
	}
	else if (opcode == 0x13 || opcode == 0x3 || opcode == 0x67) {	// I instructions
		I_type(instWord);
	}
	else if (opcode == 0x63) { // B instructions
		B_Type(instWord);
	}
	else if (opcode == 0x6F) { //J instructions
		J_Type(instWord);
	}
	else if (opcode == 0x37 || opcode == 0x17) {
		U_Type(instWord);
	}
	else if (opcode == 0x23) {
		S_Type(instWord);
	}
	else if (opcode == 0x73) {
		Ecall();
	}
	else if (opcode == 15)
	{
		cout << "\tfence" << endl;
	}
	else {
		cout << "\tUnkown Instruction \n";

	}

}

int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		unsigned int inst = radominstruction();
		std::cout << bitset<sizeof(int) * 8>(inst) << " \\\\";
		instDecExec(inst);
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
